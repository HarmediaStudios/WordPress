		</div> <!-- end #content -->
		<div id="content-bottom">
			<p id="copyright"><?php esc_html_e('Designed by ','Memoir'); ?> <a href="http://www.elegantthemes.com" title="Elegant Themes">Elegant Themes</a></p>
		</div> <!-- end #content-bottom -->
	</div> <!-- end #container -->

	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>

</body>
</html>