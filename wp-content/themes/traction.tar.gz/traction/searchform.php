<form method="get" id="search_form" action="<?php bloginfo( 'url' ); ?>/">
	<div>
		<input type="text"	name="s" id="s" class="search"/>
		<input type="submit" id="searchsubmit" value="Search" />
	</div>
</form>
